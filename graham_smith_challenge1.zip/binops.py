import math

def visual_compare(string1, string2):
    if string1 == string2:
        print "Strings are equal"
            
        return True
    else:
        length = len(string1)
        if (len(string2) < length):
            length = len(string2)

        output = ""

        print string1

        for i in range(0, length):
            if string1[i] == string2[i]:
                output += " "
            else:
                output += "x"

        print output
        print string2

        return False

def xor(string1, string2):
    length = len(string1)
    if (len(string2) < length):
        length = len(string2)

    output = ""

    for i in range(0, length):
        output += chr(ord(string1[i]) ^ ord(string2[i]))
    
    return output

def repeating_xor(string, key):
    output = ""

    for i in range(0, len(string), len(key)):
        for j in range(0, len(key)):
            if i+j < len(string):
                output += chr(ord(string[i+j]) ^ ord(key[j]))

    return output

def edit_distance(string1, string2):
    if len(string1) != len(string2):
        print "edit_distance: strings not equal length"
        return 0

    count = 0
    
    for i in range(0, len(string1)):
        val = ord(string1[i]) ^ ord(string2[i])

        for j in range(0, 8):
            if val & 0x1:
                count += 1
            val >>= 1
    
    return count

def rank_lengths(string, minlen, maxlen):
    result = []

    for length in range(minlen, maxlen):
        if len(string) < length*4:
            break

        normalized_dist = 0.0

        for i in range(0, len(string)-length*2, length*2):
            block1 = string[i:i+length]
            block2 = string[i+length:i+length*2]
            normalized_dist += edit_distance(block1, block2)/float(length)
        
        normalized_dist /= math.floor(len(string)/(length*2))

        result.append((length, normalized_dist))

    return result

def every_nth_char(string, n, offset):
    output = ""

    for i in range(0, len(string)/n*n, n):
        if i+offset >= len(string):
            print i
            print offset
            print n
            print len(string)
        
        output += string[i + offset]

    return output
        
def count_repeated_blocks(string, length):
    count = 0

    for i in range(0, len(string) // length * length, length):
        for j in range(i + length, len(string) // length * length, length):
            if string[i:i+length] == string[j:j+length]:
                count += 1

    return count
        
